﻿namespace LKS_KAB_2025
{
    partial class SYSTEM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.hari = new System.Windows.Forms.Label();
            this.panelKondisi = new System.Windows.Forms.Panel();
            this.CONTROL = new System.Windows.Forms.GroupBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lampumati = new System.Windows.Forms.Panel();
            this.lampuaktif = new System.Windows.Forms.Panel();
            this.matibutton = new System.Windows.Forms.Button();
            this.aktifbutton = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lampumaju = new System.Windows.Forms.Panel();
            this.closeobutton = new System.Windows.Forms.Button();
            this.openobutton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.closegerbang1 = new System.Windows.Forms.Button();
            this.opengerbang1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.closegerbang2 = new System.Windows.Forms.Button();
            this.opengerbang2 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.JUDUL = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.harii = new System.Windows.Forms.Label();
            this.waktu = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelPintuBox = new System.Windows.Forms.Panel();
            this.boxPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panelKondisi.SuspendLayout();
            this.CONTROL.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM3";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // hari
            // 
            this.hari.AutoSize = true;
            this.hari.Location = new System.Drawing.Point(30, 149);
            this.hari.Name = "hari";
            this.hari.Size = new System.Drawing.Size(0, 16);
            this.hari.TabIndex = 8;
            // 
            // panelKondisi
            // 
            this.panelKondisi.BackColor = System.Drawing.Color.Transparent;
            this.panelKondisi.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._78786;
            this.panelKondisi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelKondisi.Controls.Add(this.CONTROL);
            this.panelKondisi.Controls.Add(this.panel1);
            this.panelKondisi.Controls.Add(this.panel9);
            this.panelKondisi.Location = new System.Drawing.Point(0, 1);
            this.panelKondisi.Margin = new System.Windows.Forms.Padding(4);
            this.panelKondisi.Name = "panelKondisi";
            this.panelKondisi.Size = new System.Drawing.Size(2167, 1102);
            this.panelKondisi.TabIndex = 23;
            this.panelKondisi.Paint += new System.Windows.Forms.PaintEventHandler(this.panelKondisi_Paint);
            // 
            // CONTROL
            // 
            this.CONTROL.BackColor = System.Drawing.Color.Transparent;
            this.CONTROL.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._8c98fd81_e1e2_4839_9aac_52be56c5d3cb;
            this.CONTROL.Controls.Add(this.panel12);
            this.CONTROL.Controls.Add(this.panel11);
            this.CONTROL.Controls.Add(this.panel10);
            this.CONTROL.Controls.Add(this.panel7);
            this.CONTROL.Controls.Add(this.panel2);
            this.CONTROL.Controls.Add(this.groupBox4);
            this.CONTROL.Controls.Add(this.groupBox5);
            this.CONTROL.Controls.Add(this.groupBox1);
            this.CONTROL.Controls.Add(this.groupBox2);
            this.CONTROL.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CONTROL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.CONTROL.Location = new System.Drawing.Point(3, 150);
            this.CONTROL.Name = "CONTROL";
            this.CONTROL.Size = new System.Drawing.Size(394, 971);
            this.CONTROL.TabIndex = 29;
            this.CONTROL.TabStop = false;
            this.CONTROL.Text = "KONTROL";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel12.Location = new System.Drawing.Point(17, 67);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(337, 10);
            this.panel12.TabIndex = 10;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel11.Location = new System.Drawing.Point(17, 238);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(337, 10);
            this.panel11.TabIndex = 9;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel10.Location = new System.Drawing.Point(17, 423);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(337, 10);
            this.panel10.TabIndex = 8;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel7.Location = new System.Drawing.Point(17, 612);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(337, 10);
            this.panel7.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel2.Location = new System.Drawing.Point(17, 760);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(337, 10);
            this.panel2.TabIndex = 6;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox4.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._78786;
            this.groupBox4.Controls.Add(this.lampumati);
            this.groupBox4.Controls.Add(this.lampuaktif);
            this.groupBox4.Controls.Add(this.matibutton);
            this.groupBox4.Controls.Add(this.aktifbutton);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(17, 628);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(337, 124);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "POWER";
            // 
            // lampumati
            // 
            this.lampumati.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lampumati.Location = new System.Drawing.Point(238, 94);
            this.lampumati.Name = "lampumati";
            this.lampumati.Size = new System.Drawing.Size(24, 24);
            this.lampumati.TabIndex = 5;
            // 
            // lampuaktif
            // 
            this.lampuaktif.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lampuaktif.Location = new System.Drawing.Point(78, 94);
            this.lampuaktif.Name = "lampuaktif";
            this.lampuaktif.Size = new System.Drawing.Size(24, 24);
            this.lampuaktif.TabIndex = 4;
            // 
            // matibutton
            // 
            this.matibutton.BackColor = System.Drawing.Color.Red;
            this.matibutton.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matibutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.matibutton.Location = new System.Drawing.Point(173, 43);
            this.matibutton.Name = "matibutton";
            this.matibutton.Size = new System.Drawing.Size(147, 42);
            this.matibutton.TabIndex = 1;
            this.matibutton.Text = "MATI";
            this.matibutton.UseVisualStyleBackColor = false;
            this.matibutton.Click += new System.EventHandler(this.matibutton_Click);
            // 
            // aktifbutton
            // 
            this.aktifbutton.BackColor = System.Drawing.Color.LimeGreen;
            this.aktifbutton.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aktifbutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.aktifbutton.Location = new System.Drawing.Point(20, 43);
            this.aktifbutton.Name = "aktifbutton";
            this.aktifbutton.Size = new System.Drawing.Size(147, 42);
            this.aktifbutton.TabIndex = 0;
            this.aktifbutton.Text = "AKTIF";
            this.aktifbutton.UseVisualStyleBackColor = false;
            this.aktifbutton.Click += new System.EventHandler(this.aktifbutton_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox5.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._78786;
            this.groupBox5.Controls.Add(this.panel3);
            this.groupBox5.Controls.Add(this.lampumaju);
            this.groupBox5.Controls.Add(this.closeobutton);
            this.groupBox5.Controls.Add(this.openobutton);
            this.groupBox5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(17, 439);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(337, 167);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "OTOMATIS (SENSOR)";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel3.Location = new System.Drawing.Point(238, 111);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(47, 40);
            this.panel3.TabIndex = 3;
            // 
            // lampumaju
            // 
            this.lampumaju.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lampumaju.Location = new System.Drawing.Point(238, 33);
            this.lampumaju.Name = "lampumaju";
            this.lampumaju.Size = new System.Drawing.Size(47, 40);
            this.lampumaju.TabIndex = 3;
            // 
            // closeobutton
            // 
            this.closeobutton.BackColor = System.Drawing.Color.Red;
            this.closeobutton.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeobutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.closeobutton.Location = new System.Drawing.Point(20, 95);
            this.closeobutton.Name = "closeobutton";
            this.closeobutton.Size = new System.Drawing.Size(147, 56);
            this.closeobutton.TabIndex = 1;
            this.closeobutton.Text = "CLOSE";
            this.closeobutton.UseVisualStyleBackColor = false;
            this.closeobutton.Click += new System.EventHandler(this.closeobutton_Click);
            // 
            // openobutton
            // 
            this.openobutton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.openobutton.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.openobutton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.openobutton.Location = new System.Drawing.Point(20, 33);
            this.openobutton.Name = "openobutton";
            this.openobutton.Size = new System.Drawing.Size(147, 56);
            this.openobutton.TabIndex = 0;
            this.openobutton.Text = "OPEN";
            this.openobutton.UseVisualStyleBackColor = false;
            this.openobutton.Click += new System.EventHandler(this.openobutton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._78786;
            this.groupBox1.Controls.Add(this.panel8);
            this.groupBox1.Controls.Add(this.panel6);
            this.groupBox1.Controls.Add(this.closegerbang1);
            this.groupBox1.Controls.Add(this.opengerbang1);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(17, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(337, 149);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "GERBANG 1 (BESAR)";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel8.Location = new System.Drawing.Point(238, 29);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(47, 40);
            this.panel8.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel6.Location = new System.Drawing.Point(238, 88);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(47, 40);
            this.panel6.TabIndex = 3;
            // 
            // closegerbang1
            // 
            this.closegerbang1.BackColor = System.Drawing.Color.Red;
            this.closegerbang1.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closegerbang1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.closegerbang1.Location = new System.Drawing.Point(20, 86);
            this.closegerbang1.Name = "closegerbang1";
            this.closegerbang1.Size = new System.Drawing.Size(147, 56);
            this.closegerbang1.TabIndex = 1;
            this.closegerbang1.Text = "CLOSE";
            this.closegerbang1.UseVisualStyleBackColor = false;
            this.closegerbang1.Click += new System.EventHandler(this.close_Click);
            // 
            // opengerbang1
            // 
            this.opengerbang1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.opengerbang1.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.opengerbang1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.opengerbang1.Location = new System.Drawing.Point(20, 29);
            this.opengerbang1.Name = "opengerbang1";
            this.opengerbang1.Size = new System.Drawing.Size(147, 56);
            this.opengerbang1.TabIndex = 0;
            this.opengerbang1.Text = "OPEN";
            this.opengerbang1.UseVisualStyleBackColor = false;
            this.opengerbang1.Click += new System.EventHandler(this.open_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox2.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._78786;
            this.groupBox2.Controls.Add(this.panel5);
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.closegerbang2);
            this.groupBox2.Controls.Add(this.opengerbang2);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(17, 254);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(337, 163);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "GERBANG 2 (KECIL)";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel5.Location = new System.Drawing.Point(238, 45);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(47, 40);
            this.panel5.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel4.Location = new System.Drawing.Point(238, 107);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(47, 40);
            this.panel4.TabIndex = 3;
            // 
            // closegerbang2
            // 
            this.closegerbang2.BackColor = System.Drawing.Color.Red;
            this.closegerbang2.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closegerbang2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.closegerbang2.Location = new System.Drawing.Point(20, 91);
            this.closegerbang2.Name = "closegerbang2";
            this.closegerbang2.Size = new System.Drawing.Size(147, 56);
            this.closegerbang2.TabIndex = 1;
            this.closegerbang2.Text = "CLOSE";
            this.closegerbang2.UseVisualStyleBackColor = false;
            this.closegerbang2.Click += new System.EventHandler(this.close2_Click);
            // 
            // opengerbang2
            // 
            this.opengerbang2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.opengerbang2.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.opengerbang2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.opengerbang2.Location = new System.Drawing.Point(20, 29);
            this.opengerbang2.Name = "opengerbang2";
            this.opengerbang2.Size = new System.Drawing.Size(147, 56);
            this.opengerbang2.TabIndex = 0;
            this.opengerbang2.Text = "OPEN";
            this.opengerbang2.UseVisualStyleBackColor = false;
            this.opengerbang2.Click += new System.EventHandler(this.open2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._8c98fd81_e1e2_4839_9aac_52be56c5d3cb;
            this.panel1.Controls.Add(this.JUDUL);
            this.panel1.Location = new System.Drawing.Point(-67, 14);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2323, 118);
            this.panel1.TabIndex = 27;
            // 
            // JUDUL
            // 
            this.JUDUL.AutoSize = true;
            this.JUDUL.BackColor = System.Drawing.Color.Transparent;
            this.JUDUL.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JUDUL.Location = new System.Drawing.Point(127, 25);
            this.JUDUL.Name = "JUDUL";
            this.JUDUL.Size = new System.Drawing.Size(1770, 70);
            this.JUDUL.TabIndex = 0;
            this.JUDUL.Text = "MONITORING SISTEM DAN KONTROL GERBANG OTOMATIS";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.Controls.Add(this.harii);
            this.panel9.Controls.Add(this.waktu);
            this.panel9.Controls.Add(this.button1);
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this.label1);
            this.panel9.Controls.Add(this.panelPintuBox);
            this.panel9.Controls.Add(this.boxPanel);
            this.panel9.Controls.Add(this.label2);
            this.panel9.Controls.Add(this.pictureBox2);
            this.panel9.Controls.Add(this.pictureBox1);
            this.panel9.Location = new System.Drawing.Point(413, 150);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1843, 1001);
            this.panel9.TabIndex = 34;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // harii
            // 
            this.harii.AutoSize = true;
            this.harii.BackColor = System.Drawing.Color.Transparent;
            this.harii.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.harii.Location = new System.Drawing.Point(1113, 706);
            this.harii.Name = "harii";
            this.harii.Size = new System.Drawing.Size(116, 46);
            this.harii.TabIndex = 17;
            this.harii.Text = "dddd";
            // 
            // waktu
            // 
            this.waktu.AutoSize = true;
            this.waktu.BackColor = System.Drawing.Color.Transparent;
            this.waktu.Font = new System.Drawing.Font("Arial", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waktu.Location = new System.Drawing.Point(1112, 760);
            this.waktu.Name = "waktu";
            this.waktu.Size = new System.Drawing.Size(236, 51);
            this.waktu.TabIndex = 16;
            this.waktu.Text = "HH:mm:ss";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(16, 720);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 50);
            this.button1.TabIndex = 14;
            this.button1.Text = "EXIT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(942, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 33);
            this.label6.TabIndex = 13;
            this.label6.Text = "STATUS : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(692, 290);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 33);
            this.label1.TabIndex = 11;
            // 
            // panelPintuBox
            // 
            this.panelPintuBox.BackColor = System.Drawing.Color.Transparent;
            this.panelPintuBox.Location = new System.Drawing.Point(1137, 158);
            this.panelPintuBox.Name = "panelPintuBox";
            this.panelPintuBox.Size = new System.Drawing.Size(200, 100);
            this.panelPintuBox.TabIndex = 10;
            // 
            // boxPanel
            // 
            this.boxPanel.BackColor = System.Drawing.Color.Transparent;
            this.boxPanel.Location = new System.Drawing.Point(1137, 52);
            this.boxPanel.Name = "boxPanel";
            this.boxPanel.Size = new System.Drawing.Size(200, 100);
            this.boxPanel.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 33);
            this.label2.TabIndex = 8;
            this.label2.Text = "STATUS :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::LKS_KAB_2025.Properties.Resources.download_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(125, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(315, 261);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::LKS_KAB_2025.Properties.Resources.SMKBISA_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(1290, 628);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(290, 174);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // SYSTEM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::LKS_KAB_2025.Properties.Resources._78786;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 931);
            this.Controls.Add(this.hari);
            this.Controls.Add(this.panelKondisi);
            this.Name = "SYSTEM";
            this.Text = "MONITORING SYSTEM AND CONTROL AUTOMATIC GATE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.SYSTEM_Load);
            this.panelKondisi.ResumeLayout(false);
            this.CONTROL.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label hari;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label JUDUL;
        private System.Windows.Forms.GroupBox CONTROL;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel lampumaju;
        private System.Windows.Forms.Button closeobutton;
        private System.Windows.Forms.Button openobutton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button closegerbang1;
        private System.Windows.Forms.Button opengerbang1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button matibutton;
        private System.Windows.Forms.Button aktifbutton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button closegerbang2;
        private System.Windows.Forms.Button opengerbang2;
        private System.Windows.Forms.Panel panelKondisi;
        private System.Windows.Forms.Panel lampumati;
        private System.Windows.Forms.Panel lampuaktif;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelPintuBox;
        private System.Windows.Forms.Panel boxPanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label waktu;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label harii;
    }
}

