﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Security.AccessControl;
using System.Reflection.Emit;
using System.Linq.Expressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Drawing.Drawing2D;

namespace LKS_KAB_2025
{
    public partial class SYSTEM : Form
    {
        private SerialPort serialPort;
        private int pir = 0;
        private int OPname = 0;
        private string receivedData = "";

        private Panel gerbangAnimasi;
        private const int kecepatanGerbang = 20; // Dipercepat
        private bool gerbangSedangBergerak = false;
        private string arahGerbang = "";
        private int batasKiriGerbangBesar;
        private int batasKananGerbangBesar;
        private int bigGateAngle = 0;
        private bool isGateOpen = false;

        private Panel gerbangKecil;
        private bool isSmallGateOpen = false;
        private int smallGateAngle = 0;
        private int batasKiriGerbangKecil;
        private int batasKananGerbangKecil;

        private const int GATE_WIDTH = 650;  // Increased from 600
        private const int GATE_HEIGHT = 250; // Increased from 250
        private const int SMALL_GATE_WIDTH = 150; // Increased from 120
        private const int WHEEL_DIAMETER = 70; // Increased from 50

        private int titikAsalGerbangKecil;
        private int titikAsalGerbangBesar;

        private const int STRIPE_COUNT = 16;
        private bool isBoxOpen = false;
        public SYSTEM()
        {
            InitializeComponent();
            InitializeSerialPort();
            timer1 = new System.Windows.Forms.Timer();
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            timer1.Start();
            timer2.Start();
            timer2.Interval = 30;
            timer2.Tick += timer1_Tick;
            this.DoubleBuffered = true;
            timer3.Start();

        }
        private void SYSTEM_Load(object sender, EventArgs e)
        {
            aktifbutton.Enabled = true;
            matibutton.Enabled = false;
            opengerbang1.Enabled = false;
            opengerbang2.Enabled = false;
            openobutton.Enabled = false;
            closegerbang1.Enabled = false;
            closegerbang2.Enabled = false;
            closeobutton.Enabled = false;

            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);

            gerbangAnimasi = new TransparentPanel();
            gerbangAnimasi.Size = new Size(GATE_WIDTH, GATE_HEIGHT + 40); // Tambahkan ruang untuk roda
            gerbangAnimasi.Location = new Point(600, 370);  // Main gate location
            gerbangAnimasi.Paint += GambarGerbang;
            this.Controls.Add(gerbangAnimasi);
            gerbangAnimasi.BringToFront();

            int sisaLebar = this.ClientSize.Width - gerbangAnimasi.Right - 50; // 50px margin kanan
            int lebarGerbangKecil = Math.Max(100, sisaLebar); // kasih minimal lebar biar ga ilang

            gerbangKecil = new TransparentPanel();
            gerbangKecil.Size = new Size(SMALL_GATE_WIDTH, GATE_HEIGHT + 30); // Tambahkan ruang untuk roda kecil
            gerbangKecil.Location = new Point(
                gerbangAnimasi.Right,  // Langsung nempel
                gerbangAnimasi.Top     // Biar rata atas
            );
            gerbangKecil.Paint += GambarGerbangKecil;

            this.Controls.Add(gerbangKecil);
            gerbangKecil.BringToFront();

            batasKiriGerbangKecil = gerbangAnimasi.Right + 10;
            batasKananGerbangKecil = this.ClientSize.Width - SMALL_GATE_WIDTH - 20;

            SetPosisiGerbangKecilDiSampingGerbangBesar(false); // kanan

            gerbangAnimasi.BackColor = Color.Transparent;
            gerbangKecil.BackColor = Color.Transparent;

            boxPanel.Location = new Point(
            label2.Left,
            label2.Bottom + 20);
            boxPanel.BringToFront();
            panelPintuBox.BringToFront();

            boxPanel.Location = new Point(
                label2.Left,
                label2.Bottom + 20);

            int boxX = this.Width - 400; // Adjusted position
            int boxY = label2.Bottom + 145;
            boxPanel = new Panel();
            boxPanel.Size = new Size(220, 160); // Slightly larger
            boxPanel.Location = new Point(boxX, boxY);
            boxPanel.BackColor = Color.FromArgb(70, 70, 70); // Darker gray
            boxPanel.Paint += BoxPanel_Paint; // Add custom paint event
            this.Controls.Add(boxPanel);

            // Enhanced Door Panel
            panelPintuBox = new Panel();
            panelPintuBox.Size = new Size(35, 110); // Slightly larger
            panelPintuBox.Location = new Point(boxPanel.Width - 35, 25);
            panelPintuBox.BackColor = Color.FromArgb(60, 60, 60); // Darker than box
            panelPintuBox.Paint += PanelPintuBox_Paint; // Add custom paint event
            boxPanel.Controls.Add(panelPintuBox);

            this.Controls.Add(boxPanel);
            boxPanel.BringToFront();        // Pastikan box panel berada di depan
            panelPintuBox.BringToFront();   // Pastikan pintu box berada di depan
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            GraphicsPath path1 = new GraphicsPath();
            path1.AddEllipse(0, 0, lampumaju.Width, lampumaju.Height);
            lampumaju.Region = new Region(path1);

            GraphicsPath path2 = new GraphicsPath();
            path2.AddEllipse(0, 0, panel3.Width, panel3.Height);
            panel3.Region = new Region(path2);

            GraphicsPath path3 = new GraphicsPath();
            path3.AddEllipse(0, 0, panel4.Width, panel4.Height);
            panel4.Region = new Region(path3);

            GraphicsPath path4 = new GraphicsPath();
            path4.AddEllipse(0, 0, panel5.Width, panel5.Height);
            panel5.Region = new Region(path4);

            GraphicsPath path5 = new GraphicsPath();
            path5.AddEllipse(0, 0, panel6.Width, panel6.Height);
            panel6.Region = new Region(path5);

            GraphicsPath path6 = new GraphicsPath();
            path6.AddEllipse(0, 0, panel8.Width, panel8.Height);
            panel8.Region = new Region(path6);

            GraphicsPath parth7 = new GraphicsPath();
            parth7.AddEllipse(0, 0, panel3.Width, panel3.Height);
            panel3.Region = new Region(parth7);

            GraphicsPath path8 = new GraphicsPath();
            path8.AddEllipse(0, 0, lampuaktif.Width, lampuaktif.Height);
            lampuaktif.Region = new Region(path8);

            GraphicsPath path9 = new GraphicsPath();
            path9.AddEllipse(0, 0, lampumati.Width, lampumati.Height);
            lampumati.Region = new Region(path9);

        }
        private void BoxPanel_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Panel box = (Panel)sender;
            Rectangle boxRect = new Rectangle(0, 0, box.Width, box.Height);

            // Main box body with gradient
            using (LinearGradientBrush brush = new LinearGradientBrush(
                boxRect,
                Color.FromArgb(80, 80, 80),
                Color.FromArgb(50, 50, 50),
                LinearGradientMode.Vertical))
            {
                g.FillRectangle(brush, boxRect);
            }

            // 3D border effect
            using (Pen borderPen = new Pen(Color.FromArgb(100, 100, 100), 3))
            {
                g.DrawRectangle(borderPen, boxRect);
            }

            // Inner border
            Rectangle innerRect = new Rectangle(3, 3, box.Width - 6, box.Height - 6);
            using (Pen innerPen = new Pen(Color.FromArgb(40, 40, 40), 1))
            {
                g.DrawRectangle(innerPen, innerRect);
            }

            // RFID scanner area (top part)
            Rectangle scannerRect = new Rectangle(10, 10, box.Width - 20, 30);
            using (SolidBrush scannerBrush = new SolidBrush(Color.FromArgb(30, 30, 30)))
            {
                g.FillRectangle(scannerBrush, scannerRect);
            }

            // Scanner light (changes color based on state)
            Rectangle ledRect = new Rectangle(box.Width - 25, 15, 10, 10);
            using (SolidBrush ledBrush = new SolidBrush(isBoxOpen ? Color.LimeGreen : Color.FromArgb(180, 0, 0)))
            {
                g.FillEllipse(ledBrush, ledRect);
            }

            // Scanner text
            using (Font font = new Font("Arial", 8, FontStyle.Bold))
            using (SolidBrush textBrush = new SolidBrush(Color.Silver))
            {
                g.DrawString("RFID SCANNER", font, textBrush, 15, 15);
            }

            // Large status text in the middle of the box
            using (Font statusFont = new Font("Arial", 14, FontStyle.Bold))
            {
                Color statusColor = isBoxOpen ? Color.LimeGreen : Color.OrangeRed;

                // Text shadow
                using (SolidBrush shadowBrush = new SolidBrush(Color.FromArgb(100, Color.Black)))
                {
                }

                // Main text
                using (SolidBrush statusBrush = new SolidBrush(statusColor))
                {
                }
            }
        }
        private void PanelPintuBox_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Panel door = (Panel)sender;
            Rectangle doorRect = new Rectangle(0, 0, door.Width, door.Height);

            // Door body with gradient
            using (LinearGradientBrush brush = new LinearGradientBrush(
                doorRect,
                Color.FromArgb(70, 70, 70),
                Color.FromArgb(40, 40, 40),
                LinearGradientMode.Vertical))
            {
                g.FillRectangle(brush, doorRect);
            }

            // Door border
            using (Pen borderPen = new Pen(Color.FromArgb(90, 90, 90), 2))
            {
                g.DrawRectangle(borderPen, doorRect);
            }

            // Door handle
            Rectangle handleRect = new Rectangle(5, door.Height / 2 - 15, 10, 30);
            using (LinearGradientBrush handleBrush = new LinearGradientBrush(
                handleRect,
                Color.FromArgb(120, 120, 120),
                Color.FromArgb(80, 80, 80),
                LinearGradientMode.Horizontal))
            {
                g.FillRectangle(handleBrush, handleRect);
            }

            // Handle details
            using (Pen handleDetailPen = new Pen(Color.FromArgb(150, 150, 150), 1))
            {
                g.DrawLine(handleDetailPen, 7, door.Height / 2 - 10, 13, door.Height / 2 - 10);
                g.DrawLine(handleDetailPen, 7, door.Height / 2, 13, door.Height / 2);
                g.DrawLine(handleDetailPen, 7, door.Height / 2 + 10, 13, door.Height / 2 + 10);
            }

            // Hinge at the top
            Rectangle hingeRect = new Rectangle(door.Width - 15, 10, 10, 20);
            using (SolidBrush hingeBrush = new SolidBrush(Color.FromArgb(90, 90, 90)))
            {
                g.FillRectangle(hingeBrush, hingeRect);
            }

            // Hinge screws
            using (SolidBrush screwBrush = new SolidBrush(Color.FromArgb(150, 150, 150)))
            {
                g.FillEllipse(screwBrush, door.Width - 12, 15, 4, 4);
                g.FillEllipse(screwBrush, door.Width - 12, 25, 4, 4);
            }
        }
        private void GambarGerbang(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.Clear(SystemColors.InactiveCaption);

            int wheelDiameter = 30;
            int gateBodyHeight = GATE_HEIGHT;
            Rectangle gateRect = new Rectangle(0, 0, GATE_WIDTH, gateBodyHeight);

            // Warna oranye cerah (seperti semula)
            using (LinearGradientBrush brush = new LinearGradientBrush(gateRect, Color.FromArgb(255, 200, 120), Color.FromArgb(255, 150, 60), LinearGradientMode.Vertical))
                g.FillRectangle(brush, gateRect);

            using (Pen outerPen = new Pen(Color.FromArgb(80, 80, 80), 3))
                g.DrawRectangle(outerPen, gateRect);

            using (Pen innerPen = new Pen(Color.Silver, 1))
                g.DrawRectangle(innerPen, new Rectangle(gateRect.X + 3, gateRect.Y + 3, gateRect.Width - 6, gateRect.Height - 6));

            int stripeSpacing = GATE_WIDTH / (STRIPE_COUNT + 1);
            for (int i = 1; i <= STRIPE_COUNT; i++)
            {
                int x = gateRect.X + i * stripeSpacing;
                using (Pen stripePen = new Pen(Color.White, 2))
                {
                    g.DrawLine(stripePen, x, gateRect.Top + 6, x, gateRect.Bottom - 6);
                }
            }

            g.DrawLine(Pens.White, gateRect.Left + 3, gateRect.Top + 3, gateRect.Right - 3, gateRect.Top + 3);

            // Gagang persegi di kiri
            Rectangle gagangBesar = new Rectangle(
                gateRect.Left + 6,
                gateRect.Top + gateRect.Height / 2 - 15,
                6,
                30);

            using (SolidBrush handleBrush = new SolidBrush(Color.DarkSlateGray))
            {
                g.FillRectangle(handleBrush, gagangBesar);
                g.DrawRectangle(Pens.Black, gagangBesar);
            }

            int wheelY = gateRect.Bottom + wheelDiameter / 2 - 2;
            int leftWheelX = gateRect.Left + wheelDiameter / 2;
            int rightWheelX = gateRect.Right - wheelDiameter / 2;

            DrawMercedesWheel(g, leftWheelX, wheelY, wheelDiameter);
            DrawMercedesWheel(g, rightWheelX, wheelY, wheelDiameter);
        }
        private void DrawMercedesWheel(Graphics g, int centerX, int centerY, int diameter)
        {
            int outerRadius = diameter / 2;
            int rimThickness = 9;
            int innerRadius = outerRadius - rimThickness;
            int centerHubRadius = innerRadius / 2;

            Rectangle outerRect = new Rectangle(centerX - outerRadius, centerY - outerRadius, diameter, diameter);
            Rectangle innerRect = new Rectangle(centerX - innerRadius, centerY - innerRadius, innerRadius * 2, innerRadius * 2);
            Rectangle hubRect = new Rectangle(centerX - centerHubRadius, centerY - centerHubRadius, centerHubRadius * 2, centerHubRadius * 2);

            // Outer rim
            using (LinearGradientBrush rimBrush = new LinearGradientBrush(outerRect, Color.DarkGray, Color.Silver, LinearGradientMode.ForwardDiagonal))
                g.FillEllipse(rimBrush, outerRect);
            g.DrawEllipse(new Pen(Color.Black, 2), outerRect);

            // Ban dalam
            using (SolidBrush innerBrush = new SolidBrush(Color.Black))
                g.FillEllipse(innerBrush, innerRect);
            g.DrawEllipse(new Pen(Color.Black, 2), innerRect);

            // Mercedes-spoke
            for (int i = 0; i < 3; i++)
            {
                double angle = (i * 120 - 90) * Math.PI / 180.0;
                float endX = centerX + (float)(innerRadius * 0.6 * Math.Cos(angle));
                float endY = centerY + (float)(innerRadius * 0.6 * Math.Sin(angle));
                using (Pen spokePen = new Pen(Color.Silver, 3))
                    g.DrawLine(spokePen, centerX, centerY, endX, endY);
                using (SolidBrush endBrush = new SolidBrush(Color.Silver))
                    g.FillEllipse(endBrush, endX - 2.5f, endY - 2.5f, 5, 5);
            }

            // Hub tengah
            using (SolidBrush hubBrush = new SolidBrush(Color.Black))
                g.FillEllipse(hubBrush, hubRect);
            g.DrawEllipse(new Pen(Color.Silver, 2), hubRect);

            // Efek shine di velg
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddEllipse(outerRect);
                using (PathGradientBrush pgBrush = new PathGradientBrush(path))
                {
                    pgBrush.CenterColor = Color.WhiteSmoke;
                    pgBrush.SurroundColors = new[] { Color.Transparent };
                    pgBrush.CenterPoint = new Point(centerX - 5, centerY - 5);
                    g.FillEllipse(pgBrush, outerRect);
                }
            }

            // Glow halus di tengah
            Rectangle glowRect = new Rectangle(centerX - 4, centerY - 4, 8, 8);
            using (SolidBrush glow = new SolidBrush(Color.LightYellow))
                g.FillEllipse(glow, glowRect);

            // Bayangan bawah roda
            using (SolidBrush shadowBrush = new SolidBrush(Color.FromArgb(40, Color.Black)))
            {
                Rectangle shadowRect = new Rectangle(outerRect.X, outerRect.Bottom - 2, outerRect.Width, 4);
                g.FillEllipse(shadowBrush, shadowRect);
            }
        }
        private void GambarGerbangKecil(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.Clear(SystemColors.InactiveCaption);

            int wheelDiameter = 30;
            Rectangle bodyRect = new Rectangle(0, 0, gerbangKecil.Width, GATE_HEIGHT);

            // Gradasi oranye cerah (seperti gerbang besar)
            using (LinearGradientBrush brush = new LinearGradientBrush(bodyRect, Color.FromArgb(255, 200, 120), Color.FromArgb(255, 150, 60), LinearGradientMode.Vertical))
                g.FillRectangle(brush, bodyRect);

            using (Pen outerPen = new Pen(Color.FromArgb(90, 90, 90), 3))
                g.DrawRectangle(outerPen, bodyRect);

            using (Pen innerPen = new Pen(Color.Silver, 1))
            {
                Rectangle innerRect = new Rectangle(bodyRect.X + 2, bodyRect.Y + 2, bodyRect.Width - 4, bodyRect.Height - 4);
                g.DrawRectangle(innerPen, innerRect);
            }

            int stripeCount = 4;
            int stripeSpacing = bodyRect.Width / (stripeCount + 1);
            for (int i = 1; i <= stripeCount; i++)
            {
                int x = bodyRect.X + i * stripeSpacing;
                using (Pen stripePen = new Pen(Color.White, 2))
                {
                    g.DrawLine(stripePen, x, bodyRect.Top + 6, x, bodyRect.Bottom - 6);
                }
            }

            // Gagang persegi kanan (sama dengan besar)
            Rectangle gagang = new Rectangle(
                bodyRect.Right - 12,
                bodyRect.Top + bodyRect.Height / 2 - 15,
                6,
                30);

            using (SolidBrush handleBrush = new SolidBrush(Color.DarkSlateGray))
            {
                g.FillRectangle(handleBrush, gagang);
                g.DrawRectangle(Pens.Black, gagang);
            }

            int wheelY = bodyRect.Bottom + wheelDiameter / 2 - 2;
            int leftWheelX = bodyRect.Left + wheelDiameter / 2;
            int rightWheelX = bodyRect.Right - wheelDiameter / 2;

            DrawMercedesWheel(g, leftWheelX, wheelY, wheelDiameter);
            DrawMercedesWheel(g, rightWheelX, wheelY, wheelDiameter);
        }
                private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serialPort1.ReadLine();
            receivedData = data;
            UpdateReceivedData(data);
        }
        private void UpdateReceivedData(string data)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(UpdateReceivedData), data);
            }
            else
            {
                string[] parseData = data.Split('|');

                if (parseData.Length == 2)
                {
                    try
                    {
                        pir = int.Parse(parseData[0]);
                        OPname = int.Parse(parseData[1]);

                        if (pir == 1)
                        {
                            label2.Text = "STATUS : TIDAK ADA ORANG TERDETEKSI !";
                            pictureBox2.Visible = false;
                        }
                        else if (pir == 0)
                        {
                            label2.Text = "STATUS : ADA ORANG TERDETEKSI !";
                            pictureBox2.Visible = true;
                        }

                        if (OPname == 0)
                        {
                            label6.Text = "STATUS : BOX TERTUTUP !";
                        }
                        else if (OPname == 1) {
                            label6.Text = "STATUS : BOX TERBUKA !";
                        }
                    }

                    catch
                    {
                        Console.WriteLine(data);
                        return;
                    }  
                }
                else
                {
                    Console.WriteLine(data);
                    return;
                }
            }
        }
        private void InitializeSerialPort()
        {
            serialPort = new SerialPort("COM3", 9600);
            serialPort.DataReceived += serialPort1_DataReceived;
            try
            {
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal membuka port serial: " + ex.Message);

            }
        }
        private void SetPosisiGerbangKecilDiSampingGerbangBesar(bool kanan = true)
        {
            if (kanan)
            {
                gerbangKecil.Location = new Point(
                    gerbangAnimasi.Right, // Nempel di sisi kanan
                    gerbangAnimasi.Top    // Tinggi sama, jadi atasnya disamakan
                );
            }
            else
            {
                gerbangKecil.Location = new Point(
                    gerbangAnimasi.Left - SMALL_GATE_WIDTH,
                    gerbangAnimasi.Top
                );
            }
        }
        private void open_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    if (isGateOpen)
                    {
                        serialPort1.Write("p"); // STOP
                        panel8.BackColor = Color.White;
                        opengerbang1.Text = "OPEN";
                        gerbangSedangBergerak = false;
                    }
                    else
                    {
                        serialPort1.Write("m"); // Buka gerbang besar
                        panel8.BackColor = Color.LimeGreen;
                        opengerbang1.Text = "STOP";
                        arahGerbang = "kanann";
                        gerbangSedangBergerak = true;
                        //timer2.Start();
                    }
                    isGateOpen = !isGateOpen;
                }
                catch
                {
                    MessageBox.Show("TIDAK DAPAT AKSES GERBANG BESAR");
                }
            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    if (!isGateOpen)
                    {
                        serialPort1.Write("p"); // STOP
                        panel6.BackColor = Color.White;
                        closegerbang1.Text = "CLOSE";
                        gerbangSedangBergerak = false;
                    }
                    else
                    {
                        serialPort1.Write("u"); // Tutup gerbang besar
                        panel6.BackColor = Color.Red;
                        closegerbang1.Text = "STOP";
                        arahGerbang = "kirii";
                        gerbangSedangBergerak = true;
                        //timer2.Start();

                    }
                    isGateOpen = !isGateOpen;
                }
                catch
                {
                    MessageBox.Show("TIDAK DAPAT AKSES GERBANG BESAR");
                }
            }
        }

        private void panelKondisi_Paint(object sender, PaintEventArgs e)
        {

        }
        private void open2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    if (isSmallGateOpen)
                    {
                        serialPort1.Write("p"); // STOP
                        panel5.BackColor = Color.White;
                        opengerbang2.Text = "OPEN";
                        gerbangSedangBergerak = false;
                    }
                    else
                    {
                        serialPort1.Write("m"); // Buka gerbang kecil
                        panel5.BackColor = Color.LimeGreen;
                        opengerbang2.Text = "STOP";
                        arahGerbang = "kiri";  // Arah gerbang ke kanan
                        gerbangSedangBergerak = true;
                        //timer1.Start();         // Mulai timer untuk pergerakan
                    }
                    isSmallGateOpen = !isSmallGateOpen;
                }
                catch
                {
                    MessageBox.Show("TIDAK DAPAT AKSES GERBANG KECIL");
                }
            }
        }
        private void close2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    if (!isSmallGateOpen)
                    {
                        serialPort1.Write("p"); // STOP
                        panel4.BackColor = Color.White;
                        closegerbang2.Text = "CLOSE";
                        gerbangSedangBergerak = false;
                    }
                    else
                    {
                        serialPort1.Write("u"); // Tutup gerbang kecil
                        panel4.BackColor = Color.Red;
                        closegerbang2.Text = "STOP";
                        arahGerbang = "kanan";  // Arah gerbang ke kiri
                        gerbangSedangBergerak = true;
                        //timer1.Start();         // Mulai timer untuk pergerakan
                    }
                    isSmallGateOpen = !isSmallGateOpen;
                }
                catch
                {
                    MessageBox.Show("TIDAK DAPAT AKSES GERBANG KECIL");
                }
            }
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void aktifbutton_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    aktifbutton.Enabled = false;
                    matibutton.Enabled = true;
                    opengerbang1.Enabled = true;
                    opengerbang2.Enabled = false;
                    openobutton.Enabled = true;
                    closegerbang1.Enabled = true;
                    closegerbang2.Enabled = false;
                    closeobutton.Enabled = true;

                    lampuaktif.BackColor = Color.LimeGreen;
                    lampumati.BackColor = Color.White;
                }
                catch
                {

                }
            }
        }
        private void openobutton_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Write("p");
                    gerbangSedangBergerak = false;
                    opengerbang2.Enabled = false;
                    closegerbang2.Enabled = false;


                    lampumaju.BackColor = Color.LimeGreen;
                    panel5.BackColor = Color.White;
                    panel4.BackColor = Color.White;
                    panel3.BackColor = Color.White;

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void closeobutton_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    // Mengaktifkan kembali tombol pengendali gerbang
                    opengerbang2.Enabled = true;
                    closegerbang2.Enabled = true;

                    // Mengubah warna lampu indikator
                    panel3.BackColor = Color.Red;
                    lampumaju.BackColor = Color.White;

                    //Memastikan sensor PIR dimatikan
                    label2.Text = "STATUS : SENSOR DIMATIKAN";

                    // Menghilangkan gambar jika PIR dimatikan
                    pictureBox2.Visible = false;

                    // Jika port serial terbuka, tidak ada aksi lebih lanjut
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Gagal menonaktifkan PIR: " + ex.Message);
                }
            }
        }

        private void matibutton_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Write("p");
                    gerbangSedangBergerak = false;

                    aktifbutton.Enabled = true;
                    matibutton.Enabled = true;
                    opengerbang1.Enabled = false;
                    opengerbang2.Enabled = false;
                    openobutton.Enabled = false;
                    closegerbang1.Enabled = false;
                    closegerbang2.Enabled = false;
                    closeobutton.Enabled = false;

                    lampuaktif.BackColor = Color.White;
                    lampumati.BackColor = Color.Red;
                    panel8.BackColor = Color.White;
                    panel6.BackColor = Color.White;
                    panel5.BackColor = Color.White;
                    panel4.BackColor = Color.White;
                    lampumaju.BackColor = Color.White;
                    panel3.BackColor = Color.White;

                    pictureBox2.Visible = false;  // Sembunyikan gambar orang
                }
                catch
                {

                }
            }
        }
        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (titikAsalGerbangKecil == 0)
            {
                titikAsalGerbangKecil = gerbangKecil.Left;
            }

            int jarakKeKiri = 120; // Geser ke kiri sejauh 30px
            batasKiriGerbangKecil = titikAsalGerbangKecil - jarakKeKiri;
            batasKananGerbangKecil = titikAsalGerbangKecil; // Gerak kanan sampai titik asal

            if (gerbangSedangBergerak)
            {
                if (arahGerbang == "kiri")
                {
                    // Bergerak ke kiri, sejauh batasKiriGerbangKecil
                    if (gerbangKecil.Left > batasKiriGerbangKecil)
                    {
                        gerbangKecil.Left -= kecepatanGerbang;
                    }
                    else
                    {
                        gerbangKecil.Left = batasKiriGerbangKecil;
                        gerbangSedangBergerak = false;
                    }
                }
                else if (arahGerbang == "kanan")
                {
                    // Bergerak ke kanan kembali ke titik asal
                    if (gerbangKecil.Left < titikAsalGerbangKecil)
                    {
                        gerbangKecil.Left += kecepatanGerbang;
                    }
                    else
                    {
                        gerbangKecil.Left = titikAsalGerbangKecil;
                        gerbangSedangBergerak = false;
                    }
                }
            }

            // Animasi buka/tutup gerbang kecil
            if (isSmallGateOpen && smallGateAngle < 90)
            {
                smallGateAngle += 5;
                gerbangKecil.Invalidate();
            }
            else if (!isSmallGateOpen && smallGateAngle > 0)
            {
                smallGateAngle -= 5;
                gerbangKecil.Invalidate();
            }

            // Pastikan tetap dalam batas yang ditentukan
            if (gerbangKecil.Left < batasKiriGerbangKecil)
                gerbangKecil.Left = batasKiriGerbangKecil;
            else if (gerbangKecil.Left > batasKananGerbangKecil)
                gerbangKecil.Left = batasKananGerbangKecil;
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            // Simpan titik asal saat pertama kali
            if (titikAsalGerbangBesar == 0)
            {
                titikAsalGerbangBesar = gerbangAnimasi.Left;
            }

            int jarakKeKanan = 175; // Geser ke kanan sejauh 30px
            batasKananGerbangBesar = titikAsalGerbangBesar + jarakKeKanan;
            int batasKiriGerbangBesar = titikAsalGerbangBesar; // Kembali ke titik asal

            if (gerbangSedangBergerak)
            {
                if (arahGerbang == "kanann")
                {
                    // Bergerak ke kanan sejauh batasKananGerbangBesar
                    if (gerbangAnimasi.Left < batasKananGerbangBesar)
                    {
                        gerbangAnimasi.Left += kecepatanGerbang;
                    }
                    else
                    {
                        gerbangAnimasi.Left = batasKananGerbangBesar;
                        gerbangSedangBergerak = false;
                    }
                }
                else if (arahGerbang == "kirii")
                {
                    // Bergerak kembali ke titik asal
                    if (gerbangAnimasi.Left > titikAsalGerbangBesar)
                    {
                        gerbangAnimasi.Left -= kecepatanGerbang;
                    }
                    else
                    {
                        gerbangAnimasi.Left = titikAsalGerbangBesar;
                        gerbangSedangBergerak = false;
                    }
                }
            }
            // Animasi buka/tutup
            if (isGateOpen && bigGateAngle < 90)
            {
                bigGateAngle += 5;
                gerbangAnimasi.Invalidate();
            }
            else if (!isGateOpen && bigGateAngle > 0)
            {
                bigGateAngle -= 5;
                gerbangAnimasi.Invalidate();
            }

            // Batas aman (opsional)
            if (gerbangAnimasi.Left < titikAsalGerbangBesar - 100)
                gerbangAnimasi.Left = titikAsalGerbangBesar - 100;
            else if (gerbangAnimasi.Left > batasKananGerbangBesar)
                gerbangAnimasi.Left = batasKananGerbangBesar;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
            serialPort.Close();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            harii.Text = currentTime.ToString("dddd");
            waktu.Text = currentTime.ToString("HH:mm:ss");
        }
    }
    
}
