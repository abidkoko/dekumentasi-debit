#ifndef sistem_h
#define sistem_h
#include "deklarasi.h"

//inisiasi object
MFRC522 rfid(SDApin, RSTpin);

int readsensor() {
  return digitalRead(Sensor);
}

void buzz(bool kondisi) {
  digitalWrite(buzzer, kondisi);  //indikator buka tutup pintu
}

void pintu(bool kondisi) {
  digitalWrite(relay, kondisi);  //active low
  //jika 0 membuka dan 1 menutup
}

void gerbang (bool mm, bool mati){
  digitalWrite(motor1,mm);
  digitalWrite(motor2,mati);
}

bool rfid_hasil1() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    return false;
  }
  String nameRfid = String(rfid.uid.uidByte[0]) + String(rfid.uid.uidByte[1]) + String(rfid.uid.uidByte[2]) + String(rfid.uid.uidByte[3]);
  if (nameRfid == "93931931") {
    kondisipintu = true;
    pintu(0);
    buzz(1);
  } else if (nameRfid == "14211403") {
    kondisipintu = false;
    pintu(1);
    buzz(0);
  }
  rfid.PICC_HaltA();
}

void kirimdataa() {
  String visual = String(readsensor()) + "|" + String(kondisipintu);
  Serial.println(visual);
}

#endif