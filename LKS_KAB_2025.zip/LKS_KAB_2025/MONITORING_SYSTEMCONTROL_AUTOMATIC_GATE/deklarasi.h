#ifndef deklarasi_h
#define deklarasi_h

#include "sistem.h"
#include <SPI.h>
#include <Wstring.h>
#include <MFRC522.h>

/*------------------SENSOR PIN-------------------*/
#define Sensor A0 //SensorGerak (pir/obstacle)

/*------------------DIGITAL PIN-------------------*/
#define motor1 2   //driver motor in1
#define motor2 3  //driver motor in2
#define relay 4    //Module Relay & NC Selenoid Door Lock
#define buzzer 5   //buzzer indikator BukaTutup 
#define RSTpin 9   //rfid
#define SDApin 10  //rfid

/*------------------VARIABEL-------------------*/
bool kondisipintu;
int ReadRfid;
int stateOP;

#endif